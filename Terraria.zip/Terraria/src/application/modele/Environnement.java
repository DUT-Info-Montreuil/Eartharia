package application.modele;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Environnement {
	
	private int x,y;
	private int [][] map ;
	private Perso perso;
	

	public Environnement(int x, int y) {
		perso = new Perso(this, x/2, y/2);
		this.x = x;
		this.y = y;
		this.map = new int [x][y];
	}
	
	public void readMap () throws IOException {
		File file = new File("src/Terraria.csv");
		BufferedReader bfr = null;
		try {
			bfr = new BufferedReader(new FileReader(file));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		String ligne;
		String[] all_Line;
		try {
			int i = 0;
			while ((ligne = bfr.readLine()) != null) {
				all_Line = ligne.split(",");
				for(int j =0 ; j< all_Line.length; j++) {	
					this.map[i][j] = Integer.parseInt(all_Line[j].trim());
				}
				i++;
				
				//System.out.println(ligne);
			}
		} catch (NumberFormatException | IOException e) {
			e.printStackTrace();
		}
		try {
			bfr.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public int getCase(int x, int y) {
		if(x>this.y || y>this.x) {	
		}
		return this.map[x][y];
	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}
	
	public Perso getPerso () {
		return this.perso;
	}

}











