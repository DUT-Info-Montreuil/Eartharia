package application.modele;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;

public class Perso {
	protected IntegerProperty x;
    protected IntegerProperty y;
    protected Environnement env;
    
    public int getX() {
 		return x.getValue();
 	}
 	public void setX(int n){
 		x.setValue(n);
 	}

 	public IntegerProperty getxProperty(){
 		return this.x;
 	}
 	public int getY() {
 		return y.getValue();
 	}
 	public void setY(int n){
 		y.setValue(n);
 	}
 	public IntegerProperty getyProperty(){
 		return this.y;
 	}	

 	public Perso (Environnement env, int x, int y) {
 		this.x =new SimpleIntegerProperty(x) ;
		this.y =new SimpleIntegerProperty(y) ;
		this.env = env;
 	}

 	public int caseX() {
    	return this.x.get()/16;
    }
    public int caseY() {
    	return this.y.get()/16;
    }
}
