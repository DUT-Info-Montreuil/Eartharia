package application.controleur;


import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import javafx.scene.layout.TilePane;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import application.modele.Environnement;
import application.modele.Perso;
import application.vue.VuePerso;
import application.vue.vueMapTerraria;

public class Controleur implements Initializable {

	private Environnement env;
	private vueMapTerraria vueMap;
	private VuePerso vueperso;
	
	
	@FXML
	private Pane pane;
	
	@FXML
	private TilePane tileP;

	@Override
    public void initialize(URL arg0, ResourceBundle arg1) {    
		
		this.env = new Environnement(20, 20);
		
		try {
			env.readMap();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		gameLauncher();
       
	}
	
	public void gameLauncher() {
		try {
			this.vueMap = new vueMapTerraria(env, tileP);
			this.vueperso =  new VuePerso(pane, this.env.getPerso());
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@FXML
	public void move (KeyEvent k) {
		this.env.getPerso();
		Perso perso = this.env.getPerso();
		System.out.println("Key");
		 try {
		        switch (k.getCode()) {
		        
		        case UP    :
		        	perso.setY(perso.getY()-4);
		        				//this.direction = 0;
		        		
		            break;
		        
		        case RIGHT :
		        	perso.setX(perso.getX()+4);

		        				//this.direction = 1;
		        			
		            break;
		        
		        case DOWN  :perso.setY(perso.getY()+4);
		        	break;
		        
		        case LEFT  :perso.setX(perso.getX()-4);
		        	break;
		        		        
		        default:
		            break;
		        }
		        }catch (Exception e) {
		        	System.out.println("Limite map !");
		        }
		
	}
    
}


