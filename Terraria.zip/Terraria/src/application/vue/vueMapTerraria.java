package application.vue;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import application.modele.Environnement;
import javafx.geometry.Rectangle2D;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.TilePane;

public class vueMapTerraria {
	
	private Environnement terrain;
	private TilePane TileP;
	private Image imgTileP;
	private ImageView imgV;
	
	public vueMapTerraria(Environnement terrain, TilePane tileP) throws FileNotFoundException {

		this.terrain = terrain;
		this.TileP = tileP;
		initTerrain();
	}
	
	public void initTerrain() throws FileNotFoundException {
		FileInputStream fichierTileSet = null;
		try {
			fichierTileSet = new FileInputStream("src/ressources/tuile_zelda.png");
		} catch (Exception e) {
			e.printStackTrace();
		}
		this.imgTileP = new Image(fichierTileSet);
		System.out.println(imgTileP.getWidth());

		this.TileP.setPrefColumns(20);
		for (int i = 0; i < this.terrain.getY(); i++) {
			for(int j =0; j< this.terrain.getX(); j++){
				imgV = new ImageView(this.imgTileP);
				afficherMap(imgV,this.terrain.getCase(i, j));
			}
		}
	}
		
	
	public void afficherMap(ImageView img, int id) {
			int x;
			int y;
			int colonne;
			int ligne;
			
			y = id/40;
			x = id%40;
			colonne = x*16;
			ligne = y*16;
		
		img.setViewport(new Rectangle2D(colonne,ligne, 16,16));
		this.TileP.getChildren().add(img);
	}

}
